/**
* Brain prediction request
*/
export interface BrainPredictionRequest {
requestId: new () => Map<string, BrainPredictionRequest>;
(): any;
'}
//# sourceMappingURL=event-driven-brain.d.ts.map
