export declare class SecureIdGenerator {
/**
* Generate secure random ID
*/
static generate(size: 21): 21;
'}
//# sourceMappingURL=secure-ids.d.ts.map
