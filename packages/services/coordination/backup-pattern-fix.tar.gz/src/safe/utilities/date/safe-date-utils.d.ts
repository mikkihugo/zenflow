declare const end: any;
declare const quarters: [];
//# sourceMappingURL=safe-date-utils.d.ts.map
