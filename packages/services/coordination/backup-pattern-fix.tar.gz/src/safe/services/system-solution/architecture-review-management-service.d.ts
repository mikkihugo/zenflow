declare const reviewAnalysis: any, review: any;
//# sourceMappingURL=architecture-review-management-service.d.ts.map
