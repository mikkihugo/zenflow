export default ProductManagementManager;
//# sourceMappingURL=product-management-manager.d.ts.map
