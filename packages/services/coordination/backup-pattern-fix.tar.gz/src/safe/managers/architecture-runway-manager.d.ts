/**
* Architecture Runway Manager configuration
*/
export interface ArchitectureRunwayConfig {
readonly enableAGUIIntegration: 'identified| approved| planned| in-progress||';
'}
export default ArchitectureRunwayManager;
//# sourceMappingURL=architecture-runway-manager.d.ts.map
