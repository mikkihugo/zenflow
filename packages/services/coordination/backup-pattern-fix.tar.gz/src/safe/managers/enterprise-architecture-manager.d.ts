export interface EnterpriseArchConfig {
readonly enablePrincipleValidation: false;
private config;
(): any;
constructor(_config: {}): any;
'}
//# sourceMappingURL=enterprise-architecture-manager.d.ts.map