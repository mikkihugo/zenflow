declare const reasoning: any;
declare const priorityMultiplier: number;
declare const featuresPerQuarter: number;
//# sourceMappingURL=product-manager-coordinator.d.ts.map
