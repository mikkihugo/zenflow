export default SolutionManager;
//# sourceMappingURL=solution-manager.d.ts.map
