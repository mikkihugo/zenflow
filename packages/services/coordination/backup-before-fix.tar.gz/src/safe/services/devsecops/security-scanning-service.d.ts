declare const uniqueFindings: [];
//# sourceMappingURL=security-scanning-service.d.ts.map
