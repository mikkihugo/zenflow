export default ValueStreamOptimizationEngine;
//# sourceMappingURL=value-stream-optimization-engine.d.ts.map
