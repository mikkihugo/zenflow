export default SolutionTrainEngineerManager;
//# sourceMappingURL=solution-train-engineer-manager.d.ts.map
