export declare const WorkflowStepSchema: any;
//# sourceMappingURL=workflow-schemas.d.ts.map
