export declare class DateCalculator {
/**
* Calculate duration in milliseconds
*/
static getDurationMs(startDate: new () => Date): any;
'}
//# sourceMappingURL=date-calculator.d.ts.map
